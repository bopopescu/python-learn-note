#!/usr/python/bin/python3
# -*- coding:utf-8 -*-
############################
#File Name: taffile_simple_example.py
#Author: ykyk
#Mail: 525178992@qq.com
#Created Time: 2019-01-03 21:12:19
############################

import tarfile
with tarfile.open('cclang.tar') as t:
    for member_info in t.getmembers():
        print(member_info.name)

